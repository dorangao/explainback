// Server/CLI module only. Never bundle this module with a browser application.
export const META_ENDPOINT = 'https://api.meta.ai/v1/responses';
export const DEFAULT_META_MODEL = 'muse-spark-1.3';

export async function callMeta({
  apiKey,
  input,
  model = DEFAULT_META_MODEL,
  instructions,
  reasoningEffort,
  maxOutputTokens = 2048,
  tools,
  timeoutMs = 30_000,
  fetchImpl = globalThis.fetch,
} = {}) {
  if (typeof apiKey !== 'string' || !apiKey.trim()) {
    throw new Error('MODEL_API_KEY is missing. Set it privately in your shell or .env.local.');
  }
  if (typeof input !== 'string' || !input.trim()) {
    throw new Error('input must be non-empty text.');
  }

  const signal = AbortSignal.timeout(timeoutMs);
  let response;
  try {
    response = await fetchImpl(META_ENDPOINT, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${apiKey.trim()}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ model, input, store: false, max_output_tokens: maxOutputTokens,
        ...(instructions ? { instructions } : {}),
        ...(reasoningEffort ? { reasoning: { effort: reasoningEffort } } : {}),
        ...(tools ? { tools, tool_choice: 'auto', parallel_tool_calls: false } : {}) }),
      signal,
      redirect: 'error',
    });
  } catch {
    // Do not propagate transport errors that may contain headers or request data.
    throw new Error(signal.aborted ? 'Meta request timed out.' : 'Could not reach Meta Model API. Check your network connection.');
  }
  if (!response.ok) {
    const guidance = {
      401: 'Check your Meta API key.',
      403: 'Check account and model access.',
      404: 'Check META_MODEL against your available models.',
      429: 'Check credits and rate limits before retrying.',
    }[response.status] ?? 'Check the Meta dashboard before retrying.';
    throw new Error(`Meta API returned HTTP ${response.status}. ${guidance}`);
  }

  let data;
  try {
    data = await response.json();
  } catch {
    throw new Error(signal.aborted ? 'Meta request timed out.' : 'Meta API returned invalid JSON.');
  }
  if (data?.status !== 'completed') throw new Error('Meta response was not completed; no success was recorded.');
  if (tools) {
    const calls = (Array.isArray(data.output) ? data.output : []).filter(item => item?.type === 'function_call');
    if (calls.length !== 1 || !tools.some(tool => tool.name === calls[0].name) || typeof calls[0].arguments !== 'string') {
      throw new Error('Meta must return exactly one allowed learning action.');
    }
    return { id: data.id, model: data.model, text: '', usage: data.usage,
      toolCall: { name: calls[0].name, arguments: calls[0].arguments } };
  }
  const text = (Array.isArray(data.output) ? data.output : [])
    .filter(item => item?.type === 'message' && item.role === 'assistant')
    .flatMap(item => Array.isArray(item.content) ? item.content : [])
    .filter(item => item?.type === 'output_text' && typeof item.text === 'string')
    .map(item => item.text).join('\n').trim();
  if (!text) throw new Error('Meta response contained no assistant text.');
  return { id: data.id, model: data.model, text, usage: data.usage };
}
