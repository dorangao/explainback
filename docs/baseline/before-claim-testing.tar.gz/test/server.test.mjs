import assert from 'node:assert/strict';
import { test } from 'node:test';
import { request } from 'node:http';
import { createApp } from '../src/server.mjs';

async function running(t, modelCall) {
  const server = createApp({ configured: true, modelCall });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  t.after(() => new Promise(resolve => server.close(resolve)));
  const origin = `http://127.0.0.1:${server.address().port}`;
  const post = (path, body) => fetch(origin + path, { method: 'POST', headers: { 'Content-Type': 'application/json', Origin: origin }, body: JSON.stringify(body) });
  return { origin, post };
}
const start = { problemId: 'crossing', language: 'en', adult: true, synthetic: true };
const clarification = (text, feedback='Clarify.', question='Which end?') => ({ model:'test', toolCall:{name:'ask_clarification',arguments:JSON.stringify({assessment:'ambiguous',evidence:text,feedback,question,reason:'Clarify the meaning before judging.',focus:'meaning'})} });

test('serves the workspace but never serves environment or server files', async t => {
  const { origin } = await running(t);
  const page = await fetch(origin);
  assert.equal(page.status, 200);
  assert.match(await page.text(), /ExplainBack/);
  for (const path of ['/.env.local', '/src/meta.mjs', '/package.json', '/docs/', '/assets/../.env.local']) {
    assert.equal((await fetch(origin + path)).status, 404);
  }
  assert.match(page.headers.get('content-security-policy'), /default-src 'self'/);
});

test('rejects cross-origin requests and requires adult/synthetic confirmation', async t => {
  const { origin, post } = await running(t);
  assert.equal((await fetch(origin + '/api/session', { method: 'POST', headers: { Origin: 'https://example.com', 'Content-Type': 'application/json' }, body: JSON.stringify(start) })).status, 403);
  assert.equal((await post('/api/session', { ...start, adult: false })).status, 400);
  assert.equal((await post('/api/session', { ...start, synthetic: false })).status, 400);
  assert.equal((await post('/api/session', { ...start, problemId: '__proto__' })).status, 400);
  const status = await new Promise((resolve, reject) => {
    const req = request(origin + '/api/status', { headers: { Host: 'example.com' } }, res => { res.resume(); resolve(res.statusCode); });
    req.on('error', reject); req.end();
  });
  assert.equal(status, 403);
});

test('reset during an in-flight request discards the stale result', async t => {
  let release;
  const { post } = await running(t, async args => {
    await new Promise(resolve => { release = resolve; });
    return clarification(JSON.parse(args.input).explanation);
  });
  const initial = await (await post('/api/session', start)).json();
  const pending = post('/api/turn', { sessionId: initial.sessionId, explanation: 'synthetic explanation' });
  while (!release) await new Promise(resolve => setTimeout(resolve, 1));
  await post('/api/reset', { sessionId: initial.sessionId });
  release();
  assert.equal((await pending).status, 409);
});

test('HTTP session carries learner reasoning through a live-adapter turn', async t => {
  const { post } = await running(t, async args => clarification(JSON.parse(args.input).explanation,'Please distinguish finite inputs from end behavior.','What does never mean here?'));
  const initial = await (await post('/api/session', start)).json();
  const response = await post('/api/turn', { sessionId: initial.sessionId, explanation: 'never touches' });
  assert.equal(response.status, 200);
  const body = await response.json();
  assert.equal(body.phase, 'explain');
  assert.equal(body.history[0].assessment, 'ambiguous');
  assert.equal(body.attemptsRemaining, 11);
  assert.equal((await post('/api/reset', { sessionId: initial.sessionId })).status, 200);
  assert.equal((await post('/api/turn', { sessionId: initial.sessionId, explanation: 'hello' })).status, 404);
});

test('upstream failures are safe and do not advance the learning state', async t => {
  const { post } = await running(t, async () => { throw new Error('test-secret should not reach browser'); });
  const initial = await (await post('/api/session', start)).json();
  const failed = await post('/api/turn', { sessionId: initial.sessionId, explanation: 'I think it never touches.' });
  assert.equal(failed.status, 502);
  const body = await failed.text();
  assert.doesNotMatch(body, /test-secret/);
  assert.equal(JSON.parse(body).attemptsRemaining, 11);
});

test('Chinese text survives split UTF-8 bytes in an HTTP body', async t => {
  let observed;
  const { origin, post } = await running(t, async args => {
    observed = JSON.parse(args.input).explanation;
    return clarification(observed,'请澄清。','指哪一端？');
  });
  const initial = await (await post('/api/session', { ...start, language: 'zh' })).json();
  const buffer = Buffer.from(JSON.stringify({ sessionId: initial.sessionId, explanation: '不会碰到' }));
  const split = buffer.indexOf(Buffer.from('不')) + 1;
  const status = await new Promise((resolve, reject) => {
    const req = request(origin + '/api/turn', { method: 'POST', headers: { Origin: origin, 'Content-Type': 'application/json' } }, res => { res.resume(); resolve(res.statusCode); });
    req.on('error', reject); req.write(buffer.subarray(0, split));
    setTimeout(() => req.end(buffer.subarray(split)), 5);
  });
  assert.equal(status, 200);
  assert.equal(observed, '不会碰到');
});

test('the request body and per-session attempt caps are enforced', async t => {
  let calls = 0;
  const { post } = await running(t, async args => {
    calls++;
    return clarification(JSON.parse(args.input).explanation);
  });
  assert.equal((await post('/api/session', { ...start, padding: 'x'.repeat(17000) })).status, 413);
  const initial = await (await post('/api/session', start)).json();
  for (let i=0;i<12;i++) assert.equal((await post('/api/turn', { sessionId: initial.sessionId, explanation: 'never' })).status, 200);
  assert.equal((await post('/api/turn', { sessionId: initial.sessionId, explanation: 'never' })).status, 429);
  assert.equal(calls, 12);
});

test('oversized input and duplicate requests cannot cause extra model calls', async t => {
  let calls = 0;
  let release;
  const { post } = await running(t, async args => {
    calls++;
    await new Promise(resolve => { release = resolve; });
    return clarification(JSON.parse(args.input).explanation);
  });
  const initial = await (await post('/api/session', start)).json();
  assert.equal((await post('/api/turn', { sessionId: initial.sessionId, explanation: 'x'.repeat(1201) })).status, 400);
  assert.equal(calls, 0);
  const first = post('/api/turn', { sessionId: initial.sessionId, explanation: 'never' });
  while (!release) await new Promise(resolve => setTimeout(resolve, 1));
  const duplicate = await post('/api/turn', { sessionId: initial.sessionId, explanation: 'never' });
  assert.equal(duplicate.status, 409);
  release();
  assert.equal((await first).status, 200);
  assert.equal(calls, 1);
});
