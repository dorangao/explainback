import {motionFormula,motionSummary,motionAssumptions,motionExpressions} from '../public/motion.mjs';
const pair=(en,zh)=>({en,zh});
export const motionExperimentIds=['motion-acceleration','motion-distance'];
export function executeMotionExperiment({sessionId,claimId,formulaId,experimentId,evidenceId}){
 if(![sessionId,claimId,evidenceId].every(x=>typeof x==='string'&&x.length>0&&x.length<=160)||!motionExperimentIds.includes(experimentId))throw new Error('Unsupported motion evidence.');
 const s=motionFormula(formulaId),result=motionSummary(s),f=motionExpressions(s),fmt=n=>Number(n.toFixed(4));
 const acceleration=experimentId==='motion-acceleration';
 return {version:1,id:evidenceId,sessionId,claimId,formulaId,formulaVersion:1,experimentId,method:'prescribed-velocity-calculus-v1',
  inputs:{V:s.V,T:s.T,profileA:'uniform',profileB:s.profileB,units:{velocity:'m/s',time:'s',acceleration:'m/s²',distance:'m'}},result,
  proof:pair(`${f.A}; ${f.B}, u=t/T. a=dv/dt: A=V/T; B=${s.profileB==='rising'?'2Vu/T':'2V(1-u)/T'}. Integrating v from 0 to T: s_A=VT/2; s_B=${s.profileB==='rising'?'VT/3':'2VT/3'}. Average acceleration=(V-0)/T for both. These are analytic results of the prescribed profiles, not numerical sampling.`,
   `${f.A}；${f.B}，u=t/T。a=dv/dt：A=V/T；B=${s.profileB==='rising'?'2Vu/T':'2V(1-u)/T'}。将 v 从0积分到T：s_A=VT/2；s_B=${s.profileB==='rising'?'VT/3':'2VT/3'}。两者的平均加速度都是(V-0)/T。这是所设定曲线的解析结果，不是采样推断。`),
  conclusion:acceleration
   ?pair(`Both average ${fmt(result.averageAcceleration)} m/s². At t=T/4, A accelerates at ${fmt(result.quarterAccelerationA)} m/s² and B at ${fmt(result.quarterAccelerationB)} m/s². Equal average acceleration does not fix acceleration at every instant.`,
    `两者平均加速度均为 ${fmt(result.averageAcceleration)} m/s²。在 t=T/4 时，A 的加速度为 ${fmt(result.quarterAccelerationA)} m/s²，B 为 ${fmt(result.quarterAccelerationB)} m/s²。平均相同不能决定每一瞬间的加速度。`)
   :pair(`Both reach ${fmt(s.V)} m/s after ${s.T} s, but A travels ${fmt(result.distanceA)} m and B ${fmt(result.distanceB)} m. B-A=${fmt(result.distanceDifference)} m. Distance depends on the area under the full velocity curve, not endpoints alone.`,
    `两者都在 ${s.T} s 后达到 ${fmt(s.V)} m/s，但 A 行驶 ${fmt(result.distanceA)} m，B 行驶 ${fmt(result.distanceB)} m。B-A=${fmt(result.distanceDifference)} m。路程取决于完整速度曲线下的面积，不仅是端点。`),
  limitations:pair(`Hypothetical model only. ${motionAssumptions.en} This does not verify Tesla performance or a learner's understanding.`,
   `仅是假想模型。${motionAssumptions.zh} 不核验 Tesla 性能，也不证明学习者理解正确。`)};
}
