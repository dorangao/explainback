import {problemPart,publicProblem,graphData} from './problems.mjs';
import {motionScenario,motionSummary,motionExpressions,motionTitle,motionAssumptions} from '../public/motion.mjs';
const pair=(en,zh)=>({en,zh});
const text=(s,en,zh)=>s.language==='zh'?zh:en;
const crossingAnswerFields=[{key:'asymptote',label:pair('Horizontal asymptote y =','水平渐近线 y =')},{key:'crossingX',label:pair('Crossing input x =','穿越点的输入 x =')}];
const motionAnswerFields=[{key:'averageAcceleration',label:pair('Average acceleration (m/s²)','平均加速度 (m/s²)')},{key:'distanceDifference',label:pair('Distance B − A (m)','路程 B − A (m)')}];
export function isMotion(s){return s.problemId==='acceleration';}
export function answerFields(s){return isMotion(s)?motionAnswerFields:crossingAnswerFields;}
export function answerShapeValid(s,answer){return Boolean(answer&&typeof answer==='object'&&!Array.isArray(answer)
 &&Object.keys(answer).sort().join(',')===answerFields(s).map(f=>f.key).sort().join(',')&&Object.values(answer).every(Number.isFinite));}
export function motionPart(s,variant=s.transferId){
 const m=motionScenario(s.motionConfig,variant),expressions=motionExpressions(m),summary=motionSummary(m);
 const prompt=pair(`${m.context.en}: A and B start from rest and reach ${m.speedLabel} after T=${m.T} s. Compare average versus instantaneous acceleration and the distance each travels. Explain what the endpoint speeds do and do not tell you.`,
  `${m.context.zh}：A 和 B 都从静止开始，在 T=${m.T} s 后达到 ${m.speedLabel}。比较平均与瞬时加速度、各自行驶的路程，解释端点速度能说明什么、不能说明什么。`);
 const transferPrompt=pair(`${prompt.en} Enter their shared average acceleration in m/s² and signed distance B−A in m (round to 0.01). Explain using slopes/areas; equal endpoints alone are not enough.`,
  `${prompt.zh} 请填写共同的平均加速度（m/s²）和带正负号的路程差 B−A（m），可四舍五入到0.01。用斜率或面积解释，不能仅凭端点判断。`);
 return {formula:m.id,expression:`V = ${m.speedLabel}; T = ${m.T} s; ${expressions.A}; ${expressions.B}`,
  prompt:variant?transferPrompt:prompt,purpose:variant?pair('Apply the distinction to a different everyday context, unit and motion profile.','将这一区别用于新的生活情境、单位和运动曲线。'):null,
  facts:`HYPOTHETICAL prescribed 1D motion, not Tesla telemetry. SI V=${m.V} m/s, T=${m.T} s. ${expressions.A}; ${expressions.B}. a=dv/dt; distance is integral of v. Checked results: ${JSON.stringify(summary)}. At endpoints use derivatives from within [0,T]. A supported explanation distinguishes the common average acceleration from different instantaneous accelerations or distances as appropriate to the confirmed claim. Correct values alone, or claims that equal endpoints imply equal curves/areas, are insufficient. ${motionAssumptions.en}`};
}
export function domainPart(s,variant=s.transferId){return isMotion(s)?motionPart(s,variant):problemPart('crossing',variant);}
export function primaryFormula(s){return domainPart(s,null).formula;}
export function domainPublicProblem(s){
 if(!isMotion(s))return publicProblem('crossing',s.language,s.transferId);
 const p=motionPart(s);return {id:'acceleration',title:motionTitle[s.language],expression:p.expression,prompt:p.prompt[s.language],formula:p.formula,purpose:p.purpose?.[s.language]??null};
}
export function domainGraph(s){return isMotion(s)?{kind:'motion',scenario:motionScenario(s.motionConfig,s.transferId)}:graphData('crossing',s.transferId);}
export function domainKinds(s){return isMotion(s)?['average-vs-instantaneous','same-endpoints-distance']:['finite-equality','finite-crossing','end-behavior'];}
export function domainScopes(s){return isMotion(s)?['prescribed-motion-interval']:['finite-inputs','end-behavior'];}
export function domainExperiments(s){return isMotion(s)?['motion-acceleration','motion-distance']:['finite-equality','finite-crossing','end-behavior'];}
export function eligibleExperiment(s,kind,id){
 if(isMotion(s))return id===({'average-vs-instantaneous':'motion-acceleration','same-endpoints-distance':'motion-distance'})[kind];
 return (kind==='finite-equality'?['finite-equality','finite-crossing']:[kind]).includes(id);
}
export function expectedScope(s,kind){return isMotion(s)?'prescribed-motion-interval':kind==='end-behavior'?'end-behavior':'finite-inputs';}
export function answerCorrect(s,answer){
 if(!answerShapeValid(s,answer))return false;
 if(isMotion(s)){
  const result=motionSummary(motionScenario(s.motionConfig,s.transferId));
  return answerFields(s).every(f=>Math.abs(answer[f.key]-result[f.key])<=.0100000001);
 }
 const p=problemPart('crossing',s.transferId);return answer.asymptote===p.asymptote&&answer.crossingX===p.crossings[0];
}
export function predictionPrompt(s){
 if(isMotion(s))return text(s,'Before checking, predict: do A and B have the same acceleration at t=T/4? Does the same final speed in the same time imply the same distance? Explain your prediction.',
  '核验前先预测：在 t=T/4 时 A 和 B 的加速度相同吗？同样时间达到同样末速度，路程一定相同吗？请解释。');
 return s.claim.experimentId==='end-behavior'?text(s,'Predict the limit at each end. Explain why you expect that behavior.','先预测两端的极限，并解释为什么。'):
  text(s,'Predict whether the curve equals or crosses y=0 at x=0. Explain your prediction before we check.','先预测曲线是否在 x=0 处与 y=0 相等或穿过它，并解释理由，再进行核验。');
}
export function revisionPrompt(s){return isMotion(s)?text(s,'Reconcile your claim with the checked averages, slopes and areas. What do the endpoint speeds fail to determine?','结合已核验的平均值、斜率和面积重新解释你的说法。端点速度不能决定什么？'):
 text(s,'What does this evidence establish about your claim, and what does it not establish? Explain finite input versus end behavior.','这些证据对你的说法说明了什么、没有说明什么？请区分有限输入与无穷远处的行为。');}
export function domainInstructions(s){return isMotion(s)?`This is a Roadster-inspired HYPOTHETICAL acceleration lab, not Tesla measurements/specifications. Discuss only prescribed 1D velocity profiles on [0,T]. No force/power/traction, rotation, landing or real-car safety conclusions. Capture claims as average-vs-instantaneous or same-endpoints-distance with scope prescribed-motion-interval. Choose motion-acceleration for the first, motion-distance for the second. Ambiguous or unsupported real-vehicle claims require clarification. Do not attribute the model to Tesla. After prediction, use analytic derivatives and integrals from checked results. In revision, require a reasoned distinction between average acceleration and instantaneous slope, or between endpoints and the area under v(t), according to the confirmed claim. Transfer changes context and units. The learner separately enters averageAcceleration in m/s² and signed distanceDifference B-A in m, rounding tolerance 0.01. Those correct numbers alone do not show understanding; a claim that equal endpoints force identical curves or areas requires clarification. Graphs during transfer count as help. Do not disclose hidden transfer values in hints.`:
 `For 'never touches', distinguish finite input from end behavior. Choose finite-crossing to test an uncrossable boundary, finite-equality for equality only, end-behavior for end limits. Equality alone does not prove crossing, and a plot is not proof of a limit. Require reasoning about finite crossing versus end behavior. Learner transfer fields are asymptote and crossingX.`;}
export function transferOptions(s){return isMotion(s)?[
 {id:'default',purpose:'Hypothetical e-bikes, km/h units, falling acceleration.'},{id:'alternate',purpose:'Hypothetical test carts, km/h units, rising acceleration.'}]:[
 {id:'default',purpose:'Change the asymptote height and crossing input.'},{id:'alternate',purpose:'Use a negative asymptote and a negative crossing input.'}];}
