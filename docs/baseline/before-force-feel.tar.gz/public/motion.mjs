// Prescribed 1D velocity models, not measured vehicle behavior or a force model.
export const motionTitle={en:'Roadster-inspired acceleration lab',zh:'Roadster 灵感加速度实验室'};
export const motionAssumptions={
 en:'Hypothetical 1D motion from rest, only for 0 ≤ t ≤ T. Prescribed velocity profiles; no measured Tesla data or performance specification. Drag, traction, power limits, jerk transitions, rotation and landing are not modeled. Endpoint accelerations are within-interval one-sided derivatives.',
 zh:'假想的一维运动，从静止开始，仅定义于 0 ≤ t ≤ T。速度曲线为人为设定，并非 Tesla 实测数据或性能规格。不模拟阻力、轮胎抓地力、功率限制、加加速度过渡、旋转或着陆。端点加速度是区间内的单侧导数。',
};
const scenarios=new Map();
for(const speedMph of [30,60,90])for(const duration of [1,2,3])for(const profileB of ['rising','falling']){
 const id=`motion-${speedMph}-${duration}-${profileB}`;
 scenarios.set(id,{id,V:speedMph*.44704,T:duration,profileB,speedLabel:`${speedMph} mph`,context:{en:'Hypothetical sports cars',zh:'假想跑车'}});
}
scenarios.set('motion-transfer-default',{id:'motion-transfer-default',V:10,T:5,profileB:'falling',speedLabel:'36 km/h',context:{en:'Two hypothetical e-bikes',zh:'两辆假想电动自行车'}});
scenarios.set('motion-transfer-alternate',{id:'motion-transfer-alternate',V:20,T:4,profileB:'rising',speedLabel:'72 km/h',context:{en:'Two hypothetical test carts',zh:'两辆假想测试车'}});
export function motionFormula(id){
 if(!scenarios.has(id))throw new Error('Unknown motion scenario.');
 return structuredClone(scenarios.get(id));
}
export function motionScenario(config={},transferId=null){
 if(!config||typeof config!=='object'||Array.isArray(config)||Object.keys(config).some(k=>!['speedMph','duration','profileB'].includes(k)))throw new Error('Invalid motion settings.');
 const {speedMph=60,duration=1,profileB='rising'}=config;
 if(![30,60,90].includes(speedMph)||![1,2,3].includes(duration)||!['rising','falling'].includes(profileB))throw new Error('Unsupported motion settings.');
 if(transferId!==null&&!['default','alternate'].includes(transferId))throw new Error('Unknown transfer.');
 return motionFormula(transferId?`motion-transfer-${transferId}`:`motion-${speedMph}-${duration}-${profileB}`);
}
export function motionAt(s,profile,t){
 // Do not permit arbitrary user-supplied formula parameters.
 const canonical=motionFormula(s?.id);
 if(canonical.V!==s.V||canonical.T!==s.T||canonical.profileB!==s.profileB)throw new Error('Changed motion scenario.');
 if(!Number.isFinite(t)||t<0||t>s.T||!['uniform','rising','falling'].includes(profile))throw new Error('Outside the motion domain.');
 const u=t/s.T,V=s.V,T=s.T;
 if(profile==='uniform')return {velocity:V*u,acceleration:V/T,distance:V*T*u*u/2};
 if(profile==='rising')return {velocity:V*u*u,acceleration:2*V*u/T,distance:V*T*u*u*u/3};
 return {velocity:V*(2*u-u*u),acceleration:2*V*(1-u)/T,distance:V*T*(u*u-u*u*u/3)};
}
export function motionSummary(s){
 const a=motionAt(s,'uniform',s.T),b=motionAt(s,s.profileB,s.T);
 return {averageAcceleration:s.V/s.T,distanceA:a.distance,distanceB:b.distance,distanceDifference:b.distance-a.distance,
  quarterTime:s.T/4,quarterAccelerationA:motionAt(s,'uniform',s.T/4).acceleration,quarterAccelerationB:motionAt(s,s.profileB,s.T/4).acceleration};
}
export function motionExpressions(s){
 return {A:'v_A(t) = V(t/T)',B:s.profileB==='rising'?'v_B(t) = V(t/T)²':'v_B(t) = V[2(t/T) − (t/T)²]'};
}
