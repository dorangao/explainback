import { drawGraph } from './graph.mjs';
import { evaluate } from './math.mjs';
const $ = id => document.getElementById(id);
let session = null, generation = 0, busy = false, ready = false, catalog = [];
const copy = {
  en: {
    provenance:'Baseline: bilingual adaptive coach and fixed math. Extension: claim confirmation, checked evidence, replay, and transfer report. Implementation starts October 26 Pacific; competition eligibility unresolved.',
    'claim-heading':'Is this your claim?', 'confirm-claim':'Yes, test this claim', 'revise-claim':'Revise my meaning',
    'confirm-note':'Confirmation runs locally. No Meta request.', 'evidence-heading':'Checked evidence',
    'evidence-note':'Code checks the fixed mathematical identity. Claim interpretation and reasoning assessments come from Meta and may be wrong.',
    'values-legend':'Your transfer values', 'asymptote-label':'Horizontal asymptote y =', 'crossing-label':'Crossing input x =',
    'values-note':'Enter both values with your reasoning, or leave both blank to ask for help.', 'report-heading':'Transfer evidence',
    headline: 'Make your reasoning visible.', subtitle: 'Explain in your own words. Find one gap. Try the idea somewhere new.',
    eyebrow: 'LOCAL LEARNING LAB · ADULT PROTOTYPE', 'topic-label': 'Explore an idea',
    'consent-text': 'I am 18+ and will use only synthetic adult-user examples. No real student data.',
    start: 'Start a session ↗', reset: 'Reset session', 'explanation-label': 'Explain why, not just the answer.',
    'example-label': 'Synthetic starting points:', 'example-ambiguous': 'A vague claim', 'example-misconception': 'A possible misconception',
    submit: 'Get one next step →', 'request-note': 'One live Meta request per submission. No automatic retries.',
    'graph-heading': 'Look at the behavior.', 'graph-tag': 'VERIFIED MATH', 'scrubber-label': 'Explore a finite input',
    'margin-note': 'A limit describes what happens toward an end. A value tells you what happens at one input.',
    'comparison-label': 'YOUR REASONING, SIDE BY SIDE', 'before-label': 'Where you started', 'after-label': 'On a fresh problem',
    'learning-note': 'Your explanation supports this transfer problem. One response is evidence to build on, not a claim of lasting mastery.',
    again: 'Explore another idea →', 'trail-label': 'Reasoning trail', 'empty-text': 'Choose one idea and bring a synthetic explanation.',
    'empty-note': 'English or Chinese. A small question, a visible change in thinking.',
    'footer-left': 'Local prototype · Synthetic adults only · Sessions stay in memory', 'footer-right': 'Meta feedback + deterministic graphs',
    steps: ['01 · Explain', '02 · Reflect', '03 · Transfer', '04 · Compare'],
    stages: { explain: 'YOUR REASONING', revisit: 'REVISIT ONE IDEA', transfer: 'A FRESH PROBLEM', complete: 'A CHANGE IN REASONING' },
    actions: { ask_clarification:'Clarify the meaning',ask_prediction:'Predict before checking',evaluate_point:'Check one value',reveal_graph:'Test the idea with a graph',select_transfer:'Try a targeted transfer',compare_reasoning:'Compare the reasoning' },
    labels: { ambiguous: 'LET’S CLARIFY', misconception: 'ONE POSSIBLE GAP', supported: 'REASONING SUPPORTED' },
    pending: 'Reading your reasoning…', unavailable: 'Meta key missing · configure .env.local',
    ready: 'Meta configured · live requests', graphHidden: 'Make a prediction first. We can reveal the graph when it helps test your idea.',
    placeholder: 'I think… because…', newSession: 'Session reset. Choose an idea and start again.',
  },
  zh: {
    provenance:'已有基础：双语自适应辅导与固定数学题库。新增：确认说法、核验证据、重放与迁移报告。实际开发始于太平洋时间10月26日；参赛资格尚待确认。',
    'claim-heading':'这是你想表达的说法吗？', 'confirm-claim':'是，检验这个说法', 'revise-claim':'修改我的意思',
    'confirm-note':'确认在本地完成，不发送 Meta 请求。', 'evidence-heading':'已核验的证据',
    'evidence-note':'代码核验固定数学恒等式。说法解读和推理评价来自 Meta，可能有误。',
    'values-legend':'你的迁移题数值', 'asymptote-label':'水平渐近线 y =', 'crossing-label':'穿越点的输入 x =',
    'values-note':'结合推理填写两个数值；如需帮助，可以将两个输入框都留空。', 'report-heading':'迁移证据',
    headline: '让你的思考看得见。', subtitle: '用自己的话讲出来，找到一个缺口，再用一道新题检验。',
    eyebrow: '本地学习实验室 · 成人原型', 'topic-label': '探索一个想法',
    'consent-text': '我已满18岁，只使用虚构的成人学习示例，不输入真实学生资料。',
    start: '开始学习 ↗', reset: '重置本次学习', 'explanation-label': '请解释为什么，而不只是给出答案。',
    'example-label': '虚构示例：', 'example-ambiguous': '一个模糊的说法', 'example-misconception': '一个可能的误解',
    submit: '获取一个下一步 →', 'request-note': '每次提交发送一次真实 Meta 请求，不会自动重试。',
    'graph-heading': '看看函数的行为。', 'graph-tag': '已核验的数学', 'scrubber-label': '探索一个有限的输入值',
    'margin-note': '极限描述趋向某一端时的行为；函数值描述某个输入处的结果。',
    'comparison-label': '对照你的两次推理', 'before-label': '最初的想法', 'after-label': '面对一道新题',
    'learning-note': '这次解释支持你在这道迁移题上的理解。一次回答只是进一步学习的依据，不代表已经长期掌握。',
    again: '探索另一个想法 →', 'trail-label': '推理记录', 'empty-text': '选择一个概念，从一段虚构的解释开始。',
    'empty-note': '中文或英文。一个小问题，一次看得见的思考变化。',
    'footer-left': '本地原型 · 仅限虚构成人示例 · 会话只保存在内存', 'footer-right': 'Meta 反馈 + 确定性图像',
    steps: ['01 · 解释', '02 · 反思', '03 · 迁移', '04 · 对照'],
    stages: { explain: '讲出你的推理', revisit: '重新思考一个概念', transfer: '一道全新的题', complete: '推理的变化' },
    actions: { ask_clarification:'先澄清含义',ask_prediction:'先预测，再验证',evaluate_point:'核验一个函数值',reveal_graph:'用图像检验想法',select_transfer:'尝试针对性的迁移题',compare_reasoning:'对照两次推理' },
    labels: { ambiguous: '先澄清一下', misconception: '一个可能的理解缺口', supported: '推理得到支持' },
    pending: '正在阅读你的推理…', unavailable: '未配置 Meta 密钥 · 请检查 .env.local',
    ready: 'Meta 已配置 · 真实 API 请求', graphHidden: '先讲出预测。需要时再展开图像，检验你的想法。',
    placeholder: '我认为……因为……', newSession: '学习记录已重置。选择一个概念重新开始。',
  },
};
const language = () => $('language').value;
const t = () => copy[language()];
function localize() {
  document.documentElement.lang = language() === 'zh' ? 'zh-CN' : 'en';
  for (const [id, value] of Object.entries(t())) if (typeof value === 'string' && $(id)) $(id).textContent = value;
  t().steps.forEach((text, i) => $(`step-${i+1}`).textContent = text);
  $('explanation').placeholder = t().placeholder;
  for (const item of catalog) { const option = [...$('topic').options].find(o => o.value === item.id); if (option) option.textContent = item.title[language()]; }
  $('connection').textContent = ready ? t().ready : t().unavailable;
  drawGraph($('graph'), session?.graph, language(), Number($('scrubber').value));
}
function controls() {
  $('start').disabled = !ready || !$('adult').checked || busy || Boolean(session);
  $('topic').disabled = Boolean(session) || busy;
  $('adult').disabled = Boolean(session) || busy;
  $('submit').disabled = busy || !session || ['complete','confirm'].includes(session.phase) || session.attemptsRemaining <= 0;
  $('submit').textContent = busy ? t().pending : t().submit;
  $('submit').classList.toggle('busy', busy);
  $('explanation').disabled = busy;
  $('example-ambiguous').disabled = busy;
  $('example-misconception').disabled = busy;
  for(const id of ['confirm-claim','revise-claim','transfer-asymptote','transfer-crossing'])$(id).disabled=busy;
  for(const button of document.querySelectorAll('#evidence-records button'))button.disabled=busy;
}
async function post(path, body) {
  const response = await fetch(path, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body), signal: AbortSignal.timeout(40_000) });
  const data = await response.json();
  if (!response.ok) { const error = new Error(data.error || 'Local request failed.'); error.attemptsRemaining = data.attemptsRemaining; throw error; }
  return data;
}
function showError(message) { $('error').textContent = message; $('error').hidden = false; }
function render() {
  $('workspace').hidden = !session; $('empty').hidden = Boolean(session);
  if (!session) { controls(); return; }
  const { phase, problem, history, graph } = session;
  const claimMode=session.workflow==='claim-testing';
  const claimStages=language()==='zh'?{claim:'讲出一个说法',confirm:'确认解读',prediction:'先预测',revision:'根据证据重新解释',complete:'证据与迁移'}:{claim:'STATE A CLAIM',confirm:'CONFIRM THE INTERPRETATION',prediction:'PREDICT BEFORE CHECKING',revision:'RECONCILE THE EVIDENCE',complete:claimMode?'EVIDENCE AND TRANSFER':t().stages.complete};
  $('stage-label').textContent = (claimMode?claimStages[phase]:null)||t().stages[phase];
  if(claimMode){const steps=language()==='zh'?['01 · 说法','02 · 证据','03 · 迁移','04 · 报告']:['01 · Claim','02 · Evidence','03 · Transfer','04 · Report'];steps.forEach((v,i)=>$(`step-${i+1}`).textContent=v);}
  $('problem-title').textContent = problem.title;
  $('expression').textContent = problem.expression;
  $('prompt').textContent = phase === 'complete' ? problem.prompt : (session.probe || problem.prompt);
  const examplesRow = document.querySelector('.example-row');
  examplesRow.hidden = phase === 'transfer' || phase === 'complete'||phase==='confirm'||(claimMode&&phase!=='claim');
  $('explain-form').hidden = phase === 'complete'||phase==='confirm';
  $('transfer-values').hidden=!(claimMode&&phase==='transfer');
  $('attempts').textContent = language() === 'zh' ? `本次剩余 ${session.attemptsRemaining} 次请求` : `${session.attemptsRemaining} requests left in this session`;
  const stage = phase === 'complete' ? 4 : phase === 'transfer' ? 3 : ['revisit','prediction','revision'].includes(phase) ? 2 : 1;
  for (let i=1;i<=4;i++) { $(`step-${i}`).classList.toggle('active', i === stage); if(i===stage)$(`step-${i}`).setAttribute('aria-current','step');else $(`step-${i}`).removeAttribute('aria-current'); }
  const last = history.at(-1);
  $('feedback').hidden = !last;
  if (last) {
    $('feedback-label').textContent = t().labels[last.assessment];
    $('evidence').textContent = last.evidence;
    $('feedback-text').textContent = last.feedback;
    const actions=language()==='zh'?{propose_claim:'提出待确认的解读',run_experiment:'执行已核验的实验'}:{propose_claim:'Propose an interpretation',run_experiment:'Execute the checked experiment'};
    $('coach-action').textContent = actions[last.action]||t().actions[last.action] || '';
    $('coach-reason').textContent = `${language()==='zh'?'这一步的目的：':'Why this step: '}${last.reason}`;
    $('checked-result').hidden = !session.observation;
    if(session.observation){
      const point=session.observation;
      const name=point.expression.split('=')[0].trim().replace('(x)',`(${point.x})`);
      $('checked-result').textContent=`${language()==='zh'?'已核验的数值':'Checked value'} · ${name} = ${Number(point.y.toPrecision(8))}`;
    }
    $('next-question').textContent = phase === 'complete' ? '' : (session.probe || last.question);
    $('source').textContent = `${language()==='zh'?'真实 Meta 反馈':'Live Meta feedback'} · ${last.model || 'Meta Model API'}`;
  }
  drawGraph($('graph'), graph, language(), Number($('scrubber').value));
  $('scrubber-wrap').hidden = !graph;
  $('graph-caption').textContent = graph ? `${graph.expression} · x → −∞: y → ${graph.leftLimit}; x → ∞: y → ${graph.rightLimit}${graph.isReference?(language()==='zh'?'（上一题的参考图像）':' (reference graph from the first problem)'):''}` : t().graphHidden;
  if(graph) updatePoint();
  $('comparison').hidden = phase !== 'complete';
  $('before').textContent = session.before; $('after').textContent = session.after;
  if(session.comparison){
    $('learning-note').textContent=`${session.comparison.scaffolded?(language()==='zh'?'这道迁移题使用了额外提示。':'This transfer used additional scaffolding.'):''} ${t()['learning-note']}`;
  }
  if(phase==='transfer'&&problem.purpose){$('notice').textContent=`${language()==='zh'?'这道题检验什么：':'What this variant tests: '}${problem.purpose}`;}
  $('history').replaceChildren(...history.map((entry,i) => { const li=document.createElement('li'); li.textContent=`${i+1}. ${entry.explanation}\n${t().actions[entry.action]||''} · ${entry.reason}\n${entry.feedback}\n${entry.question}${entry.observation?`\nx=${entry.observation.x} → y=${Number(entry.observation.y.toPrecision(8))}`:''}`; return li; }));
  renderClaimWorkbench();
  controls();
}
function renderClaimWorkbench(){
  const mode=session?.workflow==='claim-testing',zh=language()==='zh';
  $('claim-confirmation').hidden=!(mode&&session.claim);
  if(mode&&session.claim){
    $('claim-heading').textContent=session.claim.confirmed?(zh?'已确认的说法':'Confirmed claim'):t()['claim-heading'];
    $('claim-buttons').hidden=session.phase!=='confirm';
    $('confirm-note').textContent=session.claim.confirmed?(zh?'学习者已确认这段解读。数学结果与说法是否成立将在证据中另行核验。':'The learner confirmed this interpretation. Whether the claim holds is checked separately in the evidence.'):t()['confirm-note'];
    $('claim-decisions-label').textContent=zh?'说法的决定记录':'Claim decisions';
    const names=zh?{proposed:'Meta 提出解读',confirm:'学习者确认 · 本地操作',revise:'学习者要求修改 · 本地操作'}:{proposed:'Meta proposed an interpretation',confirm:'Learner confirmed · local action',revise:'Learner requested revision · local action'};
    $('claim-decisions').replaceChildren(...session.claimEvents.map(e=>{const li=document.createElement('li');li.textContent=`${names[e.action]}: ${e.interpretation}`;return li;}));
    $('claim-quote').textContent=session.claim.quote;
    $('claim-interpretation').textContent=session.claim.interpretation;
    const scope=session.claim.scope==='finite-inputs'?(zh?'有限输入':'finite inputs'):(zh?'无穷远处的行为':'end behavior');
    $('claim-scope').textContent=`${zh?'范围':'Scope'}: ${scope} · ${zh?'待检验的实验':'Proposed experiment'}: ${experimentName(session.claim.experimentId)}`;
  }
  const records=mode?session.evidenceRecords:[];
  $('evidence-workbench').hidden=!records.length;
  $('evidence-records').replaceChildren(...records.map((e,i)=>{
    const item=document.createElement('article');item.className='evidence-record';
    const heading=document.createElement('h3');heading.textContent=`${i+1}. ${experimentName(e.experimentId)}`;
    const formula=document.createElement('p');formula.className='fine';formula.textContent=e.formulaId;
    const conclusion=document.createElement('p');conclusion.textContent=e.conclusion[language()];
    const proof=document.createElement('p');proof.textContent=e.proof[language()];
    const limits=document.createElement('p');limits.className='fine';limits.textContent=e.limitations[language()];
    const detail=document.createElement('details'),summary=document.createElement('summary'),data=document.createElement('pre');
    summary.textContent=zh?'查看执行记录':'Inspect execution record';data.textContent=JSON.stringify(e,null,2);detail.append(summary,data);
    const replay=document.createElement('button');replay.type='button';replay.className='example';replay.disabled=busy;
    replay.textContent=zh?'重放核验 · 0 次模型请求':'Replay check · 0 model requests';
    replay.addEventListener('click',async()=>{
      if(busy)return;const version=generation;replay.disabled=true;
      try{const result=await post('/api/replay',{sessionId:session.sessionId,evidenceId:e.id});
        if(version===generation)$('replay-status').textContent=result.verified?`${zh?'重放核验通过；未调用模型。':'Replay verified; no model call.'} ${e.id}`:(zh?'重放未通过。':'Replay failed.');
      }catch(error){if(version===generation)showError(error.message);}finally{replay.disabled=busy;}
    });
    item.append(heading,formula,conclusion,proof,limits,detail,replay);return item;
  }));
  $('transfer-report').hidden=!(mode&&['transfer','complete'].includes(session.phase));
  if(!mode)return;
  const report=session.report,outcomes=zh?{insufficient:'尚无充分证据：迁移尝试未完成。',independent:'独立迁移：本题未使用额外辅导。',assisted:'辅助迁移：本题使用了额外辅导。'}:{insufficient:'Insufficient evidence: transfer is not complete.',independent:'Independent transfer: no additional coaching on this problem.',assisted:'Assisted transfer: additional coaching was used on this problem.'};
  $('report-outcome').textContent=outcomes[report.outcome];
  $('report-checked').textContent=report.checkedAnswer?`${zh?'代码核验的数值':'Values checked by code'}: y=${report.checkedAnswer.asymptote}, x=${report.checkedAnswer.crossingX}`:'';
  $('report-judgment').textContent=report.reasoningAssessment?(zh?'Meta 判断推理得到支持；这不是代码对理解程度的证明。':'Meta assessed the reasoning as supported; code does not verify understanding.') : '';
  $('report-revision').textContent=report.revision?`${zh?'依据证据作出的解释':'Evidence-based revision'}: ${report.revision}`:'';
  $('report-refs').textContent=report.evidenceIds?`${zh?'引用证据':'Evidence references'}: ${report.evidenceIds.join(', ')}`:'';
  $('report-limit').textContent=report.limitation?.[language()]||'';
}
function experimentName(id){
 const names=language()==='zh'?{'finite-equality':'有限交点','finite-crossing':'有限穿越与两端极限','end-behavior':'两端的极限'}:{'finite-equality':'Finite intersection','finite-crossing':'Finite crossing and end limits','end-behavior':'End limits'};
 return names[id]||id;
}
function updatePoint() {
  if (!session?.graph) return;
  const x=Number($('scrubber').value), y=evaluate(session.graph.formula,x);
  $('point-value').textContent=`x = ${x.toFixed(1)} → y = ${y.toFixed(4)}`;
  drawGraph($('graph'), session.graph, language(), x);
}
function clear() {
  generation++;
  if(session) post('/api/reset',{sessionId:session.sessionId}).catch(()=>{});
  session=null;busy=false;$('explanation').value='';$('character-count').textContent='0 / 1200';
  $('transfer-asymptote').value='';$('transfer-crossing').value='';$('replay-status').textContent='';
  $('error').hidden=true;$('notice').textContent=t().newSession;render();
}
$('adult').addEventListener('change',controls);
$('language').addEventListener('change',()=>{clear();localize();controls();});
$('start').addEventListener('click',async()=>{
  if(busy||session||!$('adult').checked)return;
  busy=true;controls();const version=++generation;
  try {
    const data=await post('/api/session',{problemId:$('topic').value,language:language(),adult:true,synthetic:true,workflow:$('topic').value==='crossing'?'claim-testing':'baseline'});
    if(version!==generation)return;
    session=data;$('notice').textContent=language()==='zh'?'虚构成人示例；不输入真实个人或学生信息。':'Synthetic adult example; keep real personal and student information out.';
    $('error').hidden=true;render();$('explanation').focus();
  }catch(error){if(version===generation){$('notice').textContent=error.message;}}
  finally{if(version===generation){busy=false;controls();$('explanation').focus();}}
});
$('explain-form').addEventListener('submit',async event=>{
  event.preventDefault();if(busy||!session)return;
  const explanation=$('explanation').value.trim();if(!explanation)return;
  let answer;
  if(session.workflow==='claim-testing'&&session.phase==='transfer'){
    const a=$('transfer-asymptote').value,b=$('transfer-crossing').value;
    if(Boolean(a)!==Boolean(b)){showError(t()['values-note']);return;}
    if(a&&b)answer={asymptote:Number(a),crossingX:Number(b)};
  }
  busy=true;controls();$('error').hidden=true;const version=generation;
  try {
    const data=await post('/api/turn',{sessionId:session.sessionId,explanation,...(answer?{answer}:{})});
    if(version!==generation)return;
    session=data;$('explanation').value='';$('character-count').textContent='0 / 1200';render();$('feedback').focus();
  }catch(error){if(version===generation){
    if(Number.isInteger(error.attemptsRemaining)){session.attemptsRemaining=error.attemptsRemaining;render();}
    showError(error.name==='TimeoutError'?(language()==='zh'?'请求超时。文本已保留，请稍后手动重试。':'Request timed out. Your text is preserved; retry explicitly after the current request finishes.'):error.message);
  }}
  finally{if(version===generation){busy=false;controls();}}
});
for(const [id,decision] of [['confirm-claim','confirm'],['revise-claim','revise']])$(id).addEventListener('click',async()=>{
  if(busy||session?.phase!=='confirm')return;
  const version=generation,previous=session.claim.quote;busy=true;controls();$('error').hidden=true;
  try{
    const data=await post('/api/claim',{sessionId:session.sessionId,claimId:session.claim.id,decision});
    if(version!==generation)return;session=data;
    $('explanation').value=decision==='revise'?previous:'';$('explanation').dispatchEvent(new Event('input'));
    render();$('explanation').focus();
  }catch(error){if(version===generation)showError(error.message);}
  finally{if(version===generation){busy=false;controls();}}
});
$('explanation').addEventListener('input',()=>{$('character-count').textContent=`${$('explanation').value.length} / 1200`;});
$('reset').addEventListener('click',clear);$('again').addEventListener('click',()=>{clear();$('topic').focus();});
$('scrubber').addEventListener('input',updatePoint);
const examples={
  crossing:{en:['It can never touch the asymptote.','At every finite x, it is impossible for the curve to equal the asymptote because it is a barrier.'],zh:['曲线永远碰不到渐近线。','任何有限的 x 都不能让曲线等于渐近线，因为渐近线就是一道边界。']},
  nonzero:{en:['The denominator becomes very large, so maybe it goes down.','The limit is zero because the denominator goes to infinity, regardless of the numerator.'],zh:['分母越来越大，所以它可能会变小。','极限是零，因为分母趋向无穷大，不需要考虑分子的变化。']},
  ends:{en:['Both ends should settle down.','Both limits are 1 because the square root of x squared is always x.'],zh:['两端应该都会稳定下来。','两个极限都是 1，因为 x 平方的平方根总是 x。']},
};
for(const [id,index] of [['example-ambiguous',0],['example-misconception',1]])$(id).addEventListener('click',()=>{
  if(!session||busy)return;
  $('explanation').value=examples[session.problem.id][language()][index];$('explanation').dispatchEvent(new Event('input'));$('explanation').focus();
});
try {
  const response=await fetch('/api/status');if(!response.ok)throw new Error();
  const status=await response.json();ready=status.configured;catalog=status.problems;
  $('connection').classList.toggle('ready',ready);localize();controls();
}catch{ready=false;localize();$('connection').textContent=language()==='zh'?'本地服务器不可用':'Local server unavailable';}
