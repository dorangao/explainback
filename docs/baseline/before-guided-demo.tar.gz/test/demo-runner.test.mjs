import {test} from 'node:test';import assert from 'node:assert/strict';
import {runPresetDemo} from '../public/demo-runner.mjs';
function fixture(overrides={}){
 const calls=[],steps=[];let played=0,index=0;
 const states=[{phase:'confirm',claim:{id:'c1',kind:'rotation-torque'}},{phase:'revision',graph:{kind:'flight'}},{phase:'transfer',problem:{id:'flight',formula:'flight-transfer-default'},claim:{kind:'rotation-torque'},answerFields:[{key:'peakTorque'},{key:'touchdownOmegaA'}]},{phase:'complete',report:{outcome:'assisted'}}];
 return {calls,steps,get played(){return played;},options:{language:'en',adultConfirmed:true,traceEnabled:true,signal:new AbortController().signal,
  request:async(path,body)=>{calls.push({path,body});if(path==='/api/session')return {sessionId:'s1',phase:'claim',problem:{id:'flight'}};if(path==='/api/claim')return {sessionId:'s1',phase:'prediction',problem:{id:'flight'},claim:{kind:'rotation-torque'}};return {sessionId:'s1',problem:{id:'flight'},claim:{kind:'rotation-torque'},...states[index++]};},
  show:()=>{},step:s=>steps.push(s),wait:async()=>{},play:async()=>{played++;return true;},...overrides}};
}
test('one-click workflow makes exactly four provider submissions and plays before transfer',async()=>{
 const f=fixture();const s=await runPresetDemo(f.options);
 assert.equal(s.phase,'complete');assert.equal(f.calls.filter(c=>c.path==='/api/turn').length,4);assert.equal(f.played,1);
 assert.deepEqual(f.steps,['start','claim','confirm','prediction','play','revision','transfer','complete']);
 const confirmation=f.calls.find(c=>c.path==='/api/claim');assert.equal(confirmation.body.source,'scripted-demo');
 for(const c of f.calls.filter(c=>c.path==='/api/turn'))assert.equal(c.body.demoPreset,true);
 assert.deepEqual(f.calls.at(-1).body.answer,{peakTorque:26318.95,touchdownOmegaA:5.24});
});
test('demo does not assert adult consent or enable tracing by itself',async()=>{
 for(const flags of [{adultConfirmed:false},{traceEnabled:false}]){const f=fixture(flags);await assert.rejects(runPresetDemo(f.options));assert.equal(f.calls.length,0);}
});
test('provider clarification stops the script without retry or fabricated confirmation',async()=>{
 const f=fixture();const original=f.options.request;f.options.request=async(path,body)=>path==='/api/turn'?(f.calls.push({path,body}),{sessionId:'s1',phase:'claim'}):original(path,body);
 await assert.rejects(runPresetDemo(f.options),/unexpected/i);assert.equal(f.calls.filter(c=>c.path==='/api/turn').length,1);assert.equal(f.played,0);
});
test('cancel during a provider call prevents confirmation and subsequent calls',async()=>{
 const controller=new AbortController(),rendered=[],f=fixture({signal:controller.signal,show:s=>rendered.push(s.phase)});const original=f.options.request;
 f.options.request=async(path,body)=>{const s=await original(path,body);if(path==='/api/turn')controller.abort();return s;};
 await assert.rejects(runPresetDemo(f.options),e=>e.name==='AbortError');assert.equal(f.calls.length,2);
 assert.equal(rendered.at(-1),'confirm','Stop must reconcile a response that already advanced the server');
});
test('failed requests are not retried and interrupted playback cannot advance transfer',async()=>{
 const f=fixture();f.options.request=async()=>{throw new Error('provider unavailable');};await assert.rejects(runPresetDemo(f.options),/unavailable/);
 const p=fixture({play:async()=>false});await assert.rejects(runPresetDemo(p.options),/playback/i);assert.equal(p.calls.filter(c=>c.path==='/api/turn').length,2);
});
test('Chinese walkthrough uses localized presets and cancellation during a pause prevents calls',async()=>{
 const zh=fixture({language:'zh'});await runPresetDemo(zh.options);assert.match(zh.calls.find(c=>c.path==='/api/turn').body.explanation,/力矩/);
 const controller=new AbortController(),f=fixture({signal:controller.signal,wait:async()=>controller.abort()});await assert.rejects(runPresetDemo(f.options),e=>e.name==='AbortError');assert.equal(f.calls.filter(c=>c.path==='/api/turn').length,0);
});
